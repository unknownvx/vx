# from django.contrib import admin
# from micro_admin.models import *

# admin.site.register(LoanRepaymentEvery)
